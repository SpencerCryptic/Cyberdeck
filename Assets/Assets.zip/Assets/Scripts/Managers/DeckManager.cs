using UnityEngine;
using System.Collections.Generic;

public class DeckManager : MonoBehaviour
{
    [Header("Deck Setup")]
    public List<Card> startingDeck = new List<Card>();
    
    private List<Card> drawPile = new List<Card>();
    private List<Card> discardPile = new List<Card>();
    
    void Start()
    {
        InitializeDeck();
    }
    
    public void InitializeDeck()
    {
        drawPile.Clear();
        discardPile.Clear();
        
        // Add starting deck to draw pile
        drawPile.AddRange(startingDeck);
        ShuffleDeck();
    }
    
    public Card DrawCard()
    {
        // If draw pile empty, shuffle discard into draw pile
        if (drawPile.Count == 0)
        {
            if (discardPile.Count == 0) return null; // No cards left
            
            drawPile.AddRange(discardPile);
            discardPile.Clear();
            ShuffleDeck();
        }
        
        Card drawnCard = drawPile[0];
        drawPile.RemoveAt(0);
        return drawnCard;
    }
    
    public void AddToDiscard(Card card)
    {
        discardPile.Add(card);
    }
    
    private void ShuffleDeck()
    {
        for (int i = 0; i < drawPile.Count; i++)
        {
            Card temp = drawPile[i];
            int randomIndex = Random.Range(i, drawPile.Count);
            drawPile[i] = drawPile[randomIndex];
            drawPile[randomIndex] = temp;
        }
    }
}