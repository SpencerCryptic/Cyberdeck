using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "New Card", menuName = "Cards/Card")]
public class Card : ScriptableObject
{
    public string cardName = "New Card";
    public int cost = 1;
    public CardType type = CardType.Attack;
    public string description = "";
    public Sprite artwork;
    public List<CardEffect> effects = new List<CardEffect>();
}

public enum CardType
{
    Attack,
    Skill,
    Power
}

[System.Serializable]
public abstract class CardEffect
{
    public abstract void Execute(Character caster, Character target);
}

[System.Serializable]
public class DamageEffect : CardEffect
{
    public int damage = 6;
    
    public override void Execute(Character caster, Character target)
    {
        if (target != null)
        {
            target.TakeDamage(damage);
            Debug.Log($"{caster.name} deals {damage} damage to {target.name}!");
        }
    }
}