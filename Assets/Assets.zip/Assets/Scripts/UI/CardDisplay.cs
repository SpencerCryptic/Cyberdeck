using UnityEngine;

public class CardDisplay
{
    
}
