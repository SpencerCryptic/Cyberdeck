using UnityEngine;
using System;

public abstract class Character : MonoBehaviour
{
    [Header("Character Stats")]
    public int maxHealth = 100;
    public int currentHealth;
    
    public event Action<int> OnHealthChanged;
    public event Action OnDeath;
    
    protected virtual void Start()
    {
        currentHealth = maxHealth;
    }
    
    public virtual void TakeDamage(int damage)
    {
        currentHealth = Mathf.Max(0, currentHealth - damage);
        OnHealthChanged?.Invoke(currentHealth);
        
        if (currentHealth <= 0)
        {
            Die();
        }
    }
    
    public virtual void Heal(int amount)
    {
        currentHealth = Mathf.Min(maxHealth, currentHealth + amount);
        OnHealthChanged?.Invoke(currentHealth);
    }
    
    protected virtual void Die()
    {
        OnDeath?.Invoke();
    }
}

// ===== PLAYER CHARACTER =====
using UnityEngine;

public class PlayerCharacter : Character
{
    [Header("Player Stats")]
    public int energy = 3;
    public int maxEnergy = 3;
    
    public HandManager handManager;
    public DeckManager deckManager;
    
    public event System.Action<int> OnEnergyChanged;
    
    protected override void Start()
    {
        base.Start();
        handManager = FindObjectOfType<HandManager>();
        deckManager = FindObjectOfType<DeckManager>();
    }
    
    public void StartTurn()
    {
        energy = maxEnergy;
        OnEnergyChanged?.Invoke(energy);
        handManager.DrawCards(5); // Draw starting hand
    }
    
    public bool CanPlayCard(Card card)
    {
        return energy >= card.cost;
    }
    
    public void PlayCard(Card card, Character target = null)
    {
        if (!CanPlayCard(card)) return;
        
        energy -= card.cost;
        OnEnergyChanged?.Invoke(energy);
        
        // Execute card effects
        foreach (var effect in card.effects)
        {
            effect.Execute(this, target);
        }
        
        handManager.DiscardCard(card);
    }
}
